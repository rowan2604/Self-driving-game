from random import *
import pygame
import random
import os
import math
import numpy as np
import gym
import tensorflow as tf
from collections import deque
from keras.models import Sequential
from keras.layers import Dense
from tensorflow.keras.optimizers import Adam
# Init your variables here 

# Put your name Here 
name = "rowan_hadj"   # FirstName LastName

BRAKE = 0
ACCELERATE = 1
LEFT5 = 2
RIGHT5 = 3
NOTHING = 4

# This function will be called at the beginning 
# it will allow you to laod your model for example
def setup():
	global name
	print (name,"driver setup...")
	model = tf.keras.models.load_model('my_modelRelu22')
	return model
	# put your initialization code here
	# ....


# C3PO strategy : Return the first element in the available cells.
def drive(d1, d2, d3, d4, d5, velocity, acceleration):
	new_state = [[d1, d2, d3, d4, d5, velocity, acceleration]]
	setup()
	
	return np.argmax(setup().predict(new_state))
	# d1  front
	# d2  mid left	
	# d3  mid right
	# d4  left
	# d5  right
	# velocity : corrent velocity of the car
	
	# List of possible actions to return
	# BRAKE 
	# ACCELERATE 
	# LEFT5 
	# RIGHT5

	# PUT YOUR CODE HERE

	# return NOTHING
	#
	# if abs(d4 - d5) < 8 :
	# 	return ACCELERATE
	# elif d4 < d5 :
	# 	return LEFT5
	# else :
	# 	return RIGHT5
